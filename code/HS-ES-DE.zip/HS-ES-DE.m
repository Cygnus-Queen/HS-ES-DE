clear all;
rand('state',sum(100*clock));
Dimension=[30 50 100];
Dimension=[20];
Xmin=-100;
Xmax=100;
runs=30;
fhd=str2func('cec20_func');


for dimension=[1:1]
    D=Dimension(dimension);
    Max_FEs=10000*D*1;
    if D == 10
        Max_FEs = 1000000;
    end
    if D == 15
        Max_FEs = 3000000;
    end
    if D == 20
        Max_FEs = 10000000;
    end
    if D == 5
        Max_FEs=50000;
    end
    Max_FEs=10000*D*1;
    filename1 = "_CMA_Eps_2020_long.txt";
    filename = strcat(num2str(D),filename1);
    fp = fopen(filename,'a+');
    for func_num=[6:6]
        myans = [];
        ans_2020_8_long = [];
        for jj=1:runs
            temp_value = [];
            temp_ans = [];
            optimum = func_num * 100.0;
            opt= [100,1100,700,1900,1700,1600,2100,2200,2400,2500];
            S.FuncNo = func_num;
            outcome = [];
            problem_size = D;   
            freq_inti = 0.5;
            val_2_reach = 10^(-8);
            max_region = 100.0;
            min_region = -100.0;
            lu = [-100 * ones(1, problem_size); 100 * ones(1, problem_size)];
            pb = 0.4;
            ps_EPS = .5;

            S.Ndim = problem_size;
            S.Lband = ones(1, S.Ndim)*(-100);
            S.Uband = ones(1, S.Ndim)*(100);

            GenMaxSelected = 250; %%% For local search

            %%%% Count the number of maximum generations before as NP is dynamically
            %%%% decreased
            G_Max = 0;
            if problem_size == 5
                G_Max = 2163;
            end
            if problem_size == 10
                G_Max = 2745;
            end
            if problem_size == 15
                G_Max = 3022;
            end
            if problem_size == 20
                G_Max = 3401;
            end


            run_funcvals = [];
            RecordFEsFactor = ...
                [0.01, 0.02, 0.03, 0.05, 0.1, 0.2, 0.3, 0.4, ...
                0.5, 0.6, 0.7, 0.8, 0.9, 1.0];
            progress = numel(RecordFEsFactor);
            
            FEs=0;
            total=200;
            mu=100;
            vara=[func_num,-100,100,zeros(1,100),0,0];
            VRmin=repmat(Xmin,total,1);
            VRmax=repmat(Xmax,total,1);
            posinitial=VRmin+(VRmax-VRmin).*rand(total,D);
            e=feval(fhd,posinitial',vara(:));
            FEs=FEs+total;
            weights=log(mu+1/2)-log(1:mu)';
            weights=weights/sum(weights);
            [a1,a2]=sort(e);
            bestval=a1(1);
            
            disp(bestval);
            break;
            
            bestvec=posinitial(a2(1),:);
            pos=posinitial(a2(1:mu),:);
            meanval=mean(pos);
            stdval=std(pos);
            for k=1:total
                pos(k,:)=meanval+stdval.*randn(1,D);
            end
            for k=1:total
                for j=1:D
                    if pos(k,j)>100
                        pos(k,j)=meanval(j)+stdval(j).*randn;
                    elseif pos(k,j)<-100
                        pos(k,j)=meanval(j)+stdval(j).*randn;
                    end
                end
            end
            cc1=0;
           
            disp(bestval);
            for kk=1:100
                e=feval(fhd,pos',vara(:));
                FEs=FEs+total;       
                [a1,a2]=sort(e);
                if a1(1)<bestval
                    bestval=a1(1);
                    bestvec=pos(a2(1),:);
                end
                newpos=pos(a2(1:mu),:);
                meanval=(newpos(:,1:D)'*weights)';
                stdval=1*std(newpos);
                FV(kk)=a1(1);
                if kk>30
                    if mod(kk,20)==0
                        [aa1,aa2]=min(FV);
                        if aa2<kk-20
                            cc1=1;
                        end
                    end
                end
                for k=1:total
                    if cc1==1      %kk>300
                        a=0.96*randn(1,D);
                    else
                        a=randn(1,D);
                    end
                    pos(k,:)=meanval+stdval.*a;
                end
                for k=1:total
                    for j=1:D
                        if pos(k,j)>100
                            pos(k,j)=mod(pos(k,j),100);
                        elseif pos(k,j)<-100
                            pos(k,j)=mod(pos(k,j),-100);
                        end
                    end
                end
                disp(bestval);
            end
            
            previousbest=a1(1);
            if D<=30
                Times=1;
            else
                Times=1;
            end
            arfitnessbest=bestval.*ones(1,Times);
            xvalbest=repmat(bestvec',1,Times);
            N=D;
            for kkk=1:Times
                %sigma=0.5;
                sigma=0.2;
                stopfitness=1e-8;
                
                if D<=30
                    stopeval=Max_FEs/4;
                else
                    stopeval=Max_FEs/2;
                end
                
                    
                lambda=floor(3*log(N))+80;
                mu=lambda/2;
                weights=log(mu+1/2)-log(1:mu)';
                mu=floor(mu);
                weights=weights/sum(weights);
                mueff=sum(weights)^2/sum(weights.^2);
                cc=(4+mueff/N)/(N+4+2*mueff/N);
                cs=(mueff+2)/(N+mueff+5);
                c1=2/((N+1.3)^2+mueff);
                cmu=2*(mueff-2+1/mueff)/((N+2)^2+2*mueff/2);
                damps=1+2*max(0,sqrt((mueff-1)/(N+1))-1)+cs;
                pc=zeros(N,1);
                ps=zeros(N,1);
                B=eye(N);
                DD=eye(N);
                C=B*DD*(B*DD)';
                eigenval=0;
                chiN=N^0.5*(1-1/(4*N)+1/(21*N^2));                 %unknown
                counteval=0;
                xmean=bestvec';
                gn = 0;
                Gn = 50;
                T = 1e-11;
                while counteval<stopeval
                    for k=1:lambda
                        arz(:,k)=randn(N,1);
                        arxx(:,k)=xmean+1*sigma*B*DD*arz(:,k);
                        for jjj=1:N
                            if real(arxx(jjj,k))>100
                                arxx(jjj,k)=mod(real(arxx(jjj,k)),100);
                            elseif real(arxx(jjj,k))<k-100
                                arxx(jjj,k)=mod(real(arxx(jjj,k)),-100);
                            end
                        end
                        arfitness(k)=feval(fhd,arxx(:,k),vara(:));
                        counteval=counteval+1;
                        FEs=FEs+1;
                    end
                    [arfitness, arindex]=sort(arfitness);
                    xval=arxx(:,arindex(1));
                    
                    if (abs(previousbest - mean(arfitness) / previousbest)) <= T  
                        gn = gn + 1;
                    else
                        previousbest=mean(arfitness);
                        gn = 0;
                    end
                    
                    if gn >= Gn
                        gn = 0;
                        break;
                    end
                    if arfitnessbest(kkk)>arfitness(1)
                        arfitnessbest(kkk)=arfitness(1);
                        xvalbest(:,kkk)=arxx(:,arindex(1));
                    end
                    
                    xmean=arxx(:,arindex(1:mu))*weights;
                    zmean=arz(:,arindex(1:mu))*weights;
                    ps=(1-cs)*ps+(sqrt(cs*(2-cs)*mueff))*(B*zmean);
                    hsig=norm(ps)/sqrt(1-(1-cs)^(2*counteval/lambda))/chiN<1.4+2/(N+1);
                    pc=(1-cc)*pc+hsig*sqrt(cc*(2-cc)*mueff)*(B*DD*zmean);
                    C=(1-c1-cmu)*C+c1*(pc*pc'+(1-hsig)*cc*(2-cc)*C)+cmu*(B*DD*arz(:,arindex(1:mu)))*diag(weights)*(B*DD*arz(:,arindex(1:mu)))';
                    sigma=sigma*exp((cs/damps)*(norm(ps)/chiN-1));
                    xx(counteval/lambda)=sigma;
                    if counteval-eigenval>lambda/(cmu)/N/10
                        eigenval=counteval;
                        C=triu(C)+triu(C,1)';
                        [B,DD]=eig(C);
                        DD=diag(sqrt(diag(DD)));
                    end
                    
                    
                    
                    if arfitness(1)==arfitness(ceil(0.7*lambda))
                        sigma=sigma*exp(0.2+cs/damps);
                        xx(counteval/lambda)=sigma;
                    end
                    
                    if isnan(min(arfitness)-opt(func_num))
                        ans_2020_8_long = [ans_2020_8_long,min(temp_value)];
                        continue;
                    end
                    temp_value = [temp_value,min(arfitness)-opt(func_num)];
                    %disp(min(temp_value));
                    %break
                end
                
            end
            disp(min(arfitness)-opt(func_num));   
            %temp_ans = [temp_ans,min(arfitness)-opt(func_num)];
            disp(min(temp_value));
            temp_ans = [temp_ans,min(temp_value)];
            
            xxx = 0;
      run_funcvals = [];  
    %%  parameter settings for L-SHADE
    p_best_rate = 0.11;    %0.11
    arc_rate = 1.4;
    memory_size = 5;
    %pop_size = 18 * problem_size;   %18*D
    
    

    max_pop_size = 540.0;
    %max_pop_size = 1000.0;
    min_pop_size = 4.0;
    pop_size = round((((min_pop_size - max_pop_size) / Max_FEs) * FEs) + max_pop_size);
    SEL = round(ps_EPS*pop_size);
    %% Initialize the main population
    
    %popold = repmat(lu(1, :), pop_size, 1) + rand(pop_size, problem_size) .* (repmat(lu(2, :) - lu(1, :), pop_size, 1));
    archive.pop = zeros(0, problem_size); % the solutions stored in te archive
   
    for k=1:pop_size
       arxx(:,k)=xmean+1*sigma*B*DD*randn(N,1);
       for jjj=1:N
        if real(arxx(jjj,k))>100
         arxx(jjj,k)=mod(real(arxx(jjj,k)),100);
        elseif real(arxx(jjj,k))<k-100
           arxx(jjj,k)=mod(real(arxx(jjj,k)),-100);
        end
       end
    end
   
    popold = repmat(lu(1, :), pop_size, 1) + rand(pop_size, problem_size) .* (repmat(lu(2, :) - lu(1, :), pop_size, 1));
    [FEs,pop1] = chafen(pop_size,arxx,D,pop_size,transpose(xval),previousbest,arfitness(1),func_num,FEs); % the old population becomes the current population
    size(pop1);
    nfes = FEs;
    
    
    %pop_size = 50;
    
    %nfes = 0;
    %Max_FEs = Max_FEs - FEs;
    vara=[func_num,-100,100,zeros(1,100),0,0];
    %fitness = feval(fhd,pop',func_num);
    fitness = feval(fhd,pop1',vara(:));
    fitness = fitness';
    

    everbestfitall = realmax();
    everbestfitinrun = realmax();
    curbestfit = fitness(1);
    prebestfit = realmax();
        
    bsf_fit_var = 1e+30;
    bsf_index = 0;
    bsf_solution = zeros(1, problem_size);
    
    %%%%%%%%%%%%%%%%%%%%%%%% for out
    for i = 1 : pop_size
        nfes = nfes + 1;
        
        if fitness(i) < bsf_fit_var
            bsf_fit_var = fitness(i);
            bsf_solution = pop1(i, :);
            bsf_index = i;
        end
        
        if nfes > Max_FEs; break; end
    end
    %%%%%%%%%%%%%%%%%%%%%%%% for out
    everbestfitall = min(fitness)-opt(func_num);
    
    %fprintf(fp,'%d %e %e %e\r\n', nfes,  mean(fitness)-opt(func_num), min(fitness)-opt(func_num), everbestfitall);    %输出格式
    disp(['nfes:' ,num2str(nfes),'  mean:',num2str(mean(fitness)-opt(func_num)), '  min:',num2str(min(fitness)-opt(func_num)),'  everbestfitall:' num2str(everbestfitall)] );
    %%%%%%%%%%%%%%%%%%%%%%%% for out
    
    %%% Initialize LS population
    %locacl search based on gaussian walk
    flag_LS = false;
    counter = 0;
    popsize_LS = 10;
    
    %%% Initialize LS population for re-start 
    %10*30
    popLS = repmat(lu(1, :), popsize_LS, 1) + rand(popsize_LS, problem_size) .* (repmat(lu(2, :) - lu(1, :), popsize_LS, 1));
    fitness_LS = feval(fhd,popLS',func_num);
    fitness_LS = fitness_LS';
    nfes = nfes + popsize_LS;
    %%%%%%%%%%%%%
    [Sorted_FitVector, Indecis] = sort(fitness_LS);
    popLS = popLS(Indecis,:);%sorting the points based on obtaind result
    %==========================================================================
     %Finding the Best point in the group=======================================
    BestPoint = popLS(1, :);
    F = Sorted_FitVector(1);%saving the first best fitness
    %%%%%%%%%%%%%
    
    %停止进步则计数，计数达到一定程度就跳出
        
  
 
    run_funcvals = [run_funcvals;fitness];
    run_funcvals = [run_funcvals;fitness_LS]; 
    
    memory_sf = 0.5 .* ones(memory_size, 1);
    memory_cr = 0.5 .* ones(memory_size, 1);

    memory_freq = freq_inti*ones(memory_size, 1);
    memory_pos = 1;

    archive.NP = arc_rate * pop_size; % the maximum size of the archive
    %archive.pop = zeros(0, problem_size); % the solutions stored in te archive
    archive.funvalues = zeros(0, 1); % the function value of the archived solutions
    
    %% main loop
    gg=0;  %%% generation counter used For Sin
    igen =1;  %%% generation counter used For LS
 
    while nfes < Max_FEs
      gg=gg+1;
      if gg == 1
        pop = pop1;  
      else
        pop = popold; % the old population becomes the current population
      end
      [temp_fit, sorted_index] = sort(fitness, 'ascend');

      mem_rand_index = ceil(memory_size * rand(pop_size, 1));
      mu_sf = memory_sf(mem_rand_index);
      mu_cr = memory_cr(mem_rand_index);
      mu_freq = memory_freq(mem_rand_index);

      %% for generating crossover rate
      cr = normrnd(mu_cr, 0.1);
      term_pos = find(mu_cr == -1);
      cr(term_pos) = 0;
      cr = min(cr, 1);
      cr = max(cr, 0);
      
      %% for generating scaling factor
      sf = mu_sf + 0.1 * tan(pi * (rand(pop_size, 1) - 0.5));
      pos = find(sf <= 0);
      
      while ~ isempty(pos)
          sf(pos) = mu_sf(pos) + 0.1 * tan(pi * (rand(length(pos), 1) - 0.5));
          pos = find(sf <= 0);
      end
      
      
      freq = mu_freq + 0.1 * tan(pi*(rand(pop_size, 1) - 0.5));
      pos_f = find(freq <=0);
      while ~ isempty(pos_f)
        freq(pos_f) = mu_freq(pos_f) + 0.1 * tan(pi * (rand(length(pos_f), 1) - 0.5));
        pos_f = find(freq <= 0);
      end

      sf = min(sf, 1);
      freq = min(freq, 1);
      
      %if(nfes <= Max_FEs/2)
      if(nfes <= (Max_FEs-FEs)/2 + FEs)
          c=rand;
          if(c<0.5)
              sf = 0.5.*( sin(2.*pi.*freq_inti.*gg+pi) .* ((G_Max-gg)/G_Max) + 1 ) .* ones(pop_size,problem_size);
          else
              sf = 0.5 *( sin(2*pi .* freq(:, ones(1, problem_size)) .* gg) .* (gg/G_Max) + 1 ) .* ones(pop_size,problem_size);
          end
      end
      
      r0 = [1 : pop_size];
      
      popAll = [pop; archive.pop];
      [r1, r2] = gnR1R2(pop_size, size(popAll, 1), r0);
      
      pNP = max(round(p_best_rate * pop_size), 2); %% choose at least two best solutions
      randindex = ceil(rand(1, pop_size) .* pNP); %% select from [1, 2, 3, ..., pNP]
      randindex = max(1, randindex); %% to avoid the problem that rand = 0 and thus ceil(rand) = 0
      pbest = pop(sorted_index(randindex), :); %% randomly choose one of the top 100p% solutions

      prebestfit = curbestfit;     
      [curbestfit,ind] = min(fitness);
      curbestchrom = popold(ind, :);
      if prebestfit < everbestfitinrun
          everbestfitinrun = prebestfit;
      end      
      if prebestfit < everbestfitall
          everbestfitall = prebestfit;
      end
     
      
      vi = pop + sf(:, ones(1, problem_size)) .* (pbest - pop + pop(r1, :) - popAll(r2, :));
      vi = boundConstraint(vi, pop, lu);
      
      mask = rand(pop_size, problem_size) > cr(:, ones(1, problem_size)); % mask is used to indicate which elements of ui comes from the parent
      rows = (1 : pop_size)'; cols = floor(rand(pop_size, 1) * problem_size)+1; % choose one position where the element of ui doesn't come from the parent
      jrand = sub2ind([pop_size problem_size], rows, cols); mask(jrand) = false;
      ui = vi; ui(mask) = pop(mask);

      children_fitness = feval(fhd, ui', func_num);
      children_fitness = children_fitness';

     
      %%%% To check stagnation
      flag = false;
      bsf_fit_var_old = bsf_fit_var;
      %%%%%%%%%%%%%%%%%%%%%%%% for out
      for i = 1 : pop_size
          nfes = nfes + 1; 
          if children_fitness(i) < bsf_fit_var
              bsf_fit_var = children_fitness(i);
              bsf_solution = ui(i, :);
              bsf_index = i; 
          end
          
          if nfes > Max_FEs; break; end
      end      
      %%%%%%%%%%%%%%%%%%%%%%%% for out

      dif = abs(fitness - children_fitness);


      %% I == 1: the parent is better; I == 2: the offspring is better
      I = (fitness > children_fitness);
      goodCR = cr(I == 1);  
      goodF = sf(I == 1);
      goodFreq = freq(I == 1);
      dif_val = dif(I == 1);

%      isempty(popold(I == 1, :))   
      archive = updateArchive(archive, popold(I == 1, :), fitness(I == 1));

      [fitness, I] = min([fitness, children_fitness], [], 2);
      
      run_funcvals = [run_funcvals; fitness];
      
      popold = pop;
      popold(I == 2, :) = ui(I == 2, :);

      num_success_params = numel(goodCR);

      if num_success_params > 0
          sum_dif = sum(dif_val);
          dif_val = dif_val / sum_dif;
          
          %% for updating the memory of scaling factor
          memory_sf(memory_pos) = (dif_val' * (goodF .^ 2)) / (dif_val' * goodF);
          
          %% for updating the memory of crossover rate
          if max(goodCR) == 0 || memory_cr(memory_pos)  == -1
              memory_cr(memory_pos)  = -1;
          else
              memory_cr(memory_pos) = (dif_val' * (goodCR .^ 2)) / (dif_val' * goodCR);
          end
          
          %% for updating the memory of freq
          if max(goodFreq) == 0 || memory_freq(memory_pos)  == -1
              memory_freq(memory_pos)  = -1;
          else
              memory_freq(memory_pos) = (dif_val' * (goodFreq .^ 2)) / (dif_val' * goodFreq);
          end
          
          memory_pos = memory_pos + 1;
          if memory_pos > memory_size;  memory_pos = 1; end
      end

      %% for resizing the population size
      plan_pop_size = round((((min_pop_size - max_pop_size) / Max_FEs) * nfes) + max_pop_size);
    
      if pop_size > plan_pop_size
          reduction_ind_num = pop_size - plan_pop_size;
          if pop_size - reduction_ind_num <  min_pop_size; 
              reduction_ind_num = pop_size - min_pop_size;
          end
          
          pop_size = pop_size - reduction_ind_num;
          SEL = round(ps_EPS*pop_size);
          for r = 1 : reduction_ind_num
              [valBest indBest] = sort(fitness, 'ascend');
              worst_ind = indBest(end);
              popold(worst_ind,:) = [];
              pop(worst_ind,:) = [];
              fitness(worst_ind,:) = [];
          end
          
          archive.NP = round(arc_rate * pop_size);
          
          if size(archive.pop, 1) > archive.NP
              rndpos = randperm(size(archive.pop, 1));
              rndpos = rndpos(1 : archive.NP);
              
              archive.pop = archive.pop(rndpos, :);
          end
      end
       %%%%%%%%%%%%%%% Call LS based on Gaussian works when NP is less than 20 for the first time  %%%%%
      if pop_size <= 20
          counter = counter + 1;
      end

      if counter == 1
          flag_LS = true;
      else
          flag_LS = false;
      end

      if flag_LS == true
          r_index = randi([1 pop_size],1,popsize_LS); %1*10的1-20随机数
          %%% Pick 10 random individuals from L-SHADE pop
          for gen_LS = 0 : GenMaxSelected
              New_Point = [];%creating new point
              FitVector = [];%creating vector of fitness functions

              for i = 1 : popsize_LS
                  [NP, fit] = LS_Process(popLS(i,:),S,gg,BestPoint);
                  New_Point = [New_Point;NP];
                  FitVector = [FitVector,fit];
              end
           
              %%%%
              fittemp = FitVector;
              for i = 1 : popsize_LS
                  %%% Update those 10 random individuals from pop L-SHADE
                  if FitVector(i) < fitness(r_index(i))    %比较新产生的个体和原来群体的适应值 若新产生的好，就替换
                      fitness (r_index(i)) = FitVector(i);
                      pop(r_index(i),:) = New_Point(i,:);
                      
                  else
                      fittemp(i) =  fitness (r_index(i));  % fittemp记录所有差解的适应值 fitness记录好的 FitVector记录新的
                  end

                  %%%% Update best individual L-SHADE
                  if FitVector(i) < bsf_fit_var
                      bsf_fit_var = FitVector(i);
                      bsf_solution = New_Point(i,:);
                  end

                  nfes = nfes + 1;
                  if nfes > Max_FEs; break; end
              end
              
              %%%%%% To recored those changes
              fittemp = fittemp';
              run_funcvals = [run_funcvals; fittemp];
              
              %%%%%%%%%%%%%%
                
              [SortedFit,SortedIndex] = sort(FitVector);
              New_Point = New_Point(SortedIndex,:);
              BestPoint = New_Point(1,:);%first point is the best
              BestFitness = SortedFit(1,1);
              popLS = New_Point;
          end
      end
      if everbestfitall > min(fitness)-opt(func_num)
          everbestfitall = min(fitness)-opt(func_num);
      end
      if (nfes / Max_FEs) >= (xxx / 50)
          if  xxx > 0
             
              %fprintf(fp,'%d %e %e %e\r\n', nfes, mean(fitness)-opt(func_num), min(fitness)-opt(func_num), everbestfitall);
              disp(['nfes:' ,num2str(nfes),'  mean:',num2str(mean(fitness)-opt(func_num)), '  min:',num2str(min(fitness)-opt(func_num)),'  everbestfitall:' num2str(everbestfitall)] );
          end
          xxx = xxx + 1;
      end
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end %%%%%%%%nfes
    
    bsf_error_val = bsf_fit_var - opt(func_num);
    outcome = [outcome bsf_error_val];
    %temp_ans = [temp_ans,min(fitness)-opt(func_num)];
    temp_ans = [temp_ans,everbestfitall];
    bestans = min(temp_ans);
    myans = [myans,bestans];
            
        end
    fprintf(fp,'%e ',mean(myans));
    fprintf(fp,'%e ',std(myans));
    for num = [1:runs]
        fprintf(fp,'%e ',myans(num));
        myans(num);
    end
    fprintf(fp,'\n');
    disp(ans_2020_8_long);
    end
    
     
    clear arz;
    clear arxx;
end

% process=process'-2600
%         save afile.txt -ascii process

function [FEs,pos_new]=chafen(total,arx,D,pop_size,xval,preans,nowans,func_num,FEs)
    pos = transpose(arx);
    T = 1e-8;
    %T = 100;
    rate = 0.2;
    zero_pos = zeros(total,D);
    xy_times = 3; %差分演化的代数
    num = 0;
    
    vara=[func_num,-100,100,zeros(1,100),0,0];
    for index_times = [1:xy_times]
        for index_i=[1:total]
            r1 = randi(total,1,1);
            r2 = randi(total,1,1);
            r3 = randi(total,1,1);
            while r1 == r2 | r1 == r3 | r2 == r3
                r1 = randi(total,1,1);
                r2 = randi(total,1,1);
                r3 = randi(total,1,1);
            end
            x1 = pos(r1,:);
            x2 = pos(r2,:);
            x3 = pos(r3,:);
            v1 = x3 + rate*(x1-x2);
            %seq = randperm(30);
            %seq = seq(1:15);
            only = randi(D,1,1);
            for index_ii = [1:D]
                if index_ii == only
                    continue
                end
                prorate = rand(1); %概率
                if prorate < 0.5
                    v1(index_ii) = x3(index_ii);
                end
            end
            zero_pos (index_i,:) = v1;
        end
        pos = zero_pos;
        %num = num + 1;
        %ansval = mean(pos);
        %e=feval(fhd,ansval',vara(:));
        %FEs = FEs+1;
        
        %if abs(e - nowans) > (T * nowans)  %* abs(preans - nowans)  
        %    disp(e);
        %    break;
        %end
            
    end
    
    randIndex = randperm(size(pos,1));
    randIndex = randIndex(1:pop_size);
    pos_new = pos(randIndex,:);
    

end



