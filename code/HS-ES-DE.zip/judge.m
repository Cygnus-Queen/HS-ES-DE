mpath = "C:\Users\Lenovo\Desktop\CMA-EPS（添加跳出）\\ans.txt";
mpath = "C:\\Users\\Lenovo\\Desktop\\two\\15_CMA_Eps_20202.txt";
mpath = "C:\\Users\\Lenovo\\Desktop\\最终数据\\2020_20_long\\4HS-ES-DE.txt";
%mpath = "C:\\Users\\Lenovo\\Desktop\\最终数据\\20_CMA_Eps_2020.txt";
%mpath = "C:\\Users\\Lenovo\\Desktop\\最终数据\\results_IMODE_10_2020.txt"
x = ["AMECoDEs.txt","EDEV.txt","EPS.txt","ETI-JADE.txt","L-SHADE.txt", ...
    "LSHADE-E.txt","MLCC.txt","MPEDE 2017.txt","NDE.txt","RSP.txt"];
%a = [];

path1 = "C:\\Users\\Lenovo\\Desktop\\other_data50维度\\results_HSES_50_2014x1.txt";
path2 = "C:\\Users\\Lenovo\\Desktop\\other_data50维度\\results_Eps_50_2014.txt";
path3 = "C:\\Users\\Lenovo\\Desktop\\other_data50维度\\results_EBO_50_2014x1.txt";
path4 = "C:\\Users\\Lenovo\\Desktop\\other_data50维度\\results_UME_50_20141.txt";
path5 =  "C:\\Users\\Lenovo\\Desktop\\最终数据\\2020_20_long\\results_j2020_20_2020.txt";
%path5 = "C:\\Users\\Lenovo\\Desktop\\最终数据\\results_IMODE_20_2020_long.txt";
%path5 = "C:\\Users\\Lenovo\\Desktop\\最终数据\\20_CMA_Eps_2020.txt";
%path5 = "results_EPS_20_20201.txt";
%path5 = "results_Eps_30_2014.txt";
path5 = "C:\\Users\\Lenovo\\Desktop\\最终数据\\2020_20_long\\1IMODE.txt";

%da = fopen(path,'r');
%db = fopen(mpath,'r');
A = load(path5,"ASCII");
B = load(mpath);

amean = mean(A');
astd = std(A');


D = 30;
D = D + 2;
%amean = [amean',astd']
%A = [amean,A];


x = A(:,3:D);
y = B(:,3:D);

size(x);
x_mean = A(:,1);
y_mean = B(:,1);
ans = [];
%x2 = [2.5734 2.2521 2.36 0.20819 0.12491 2.36 4.595 2.36 0.20819 2.5265 8.9819 0.16655 2.4433 0.16655 0.16655 2.3192 2.4849 2.4433 0.16655 2.5682 8.0115 0.12491 2.4016 2.36 6.7885 2.4016 2.4433 2.2767 4.5534 2.36 4.5118 2.3183 ]
%x3 = [1.093969e+02 3.677139e+01 1.189898e+02 1.186049e+02 1.288616e+02 1.186465e+02 1.188232e+02 1.184800e+02 1.208399e+02 1.208816e+02 1.186049e+02 1.210583e+02 2.401613e+00 1.211415e+02 1.266265e+02 1.288199e+02 1.189481e+02 1.189065e+02 1.189481e+02 1.189065e+02 1.211832e+02 1.189065e+02 2.081870e-01 1.231166e+02 1.188232e+02 1.351430e+02 1.188648e+02 1.186049e+02 1.189065e+02 2.276701e+00 1.288199e+02 1.185632e+02] 
%[~,h1]=ranksum(x2, x3);
%h1

for i=[1:10]
    x1 = x(i,:);
    y1 = y(i,:);
    [~,h1]=ranksum(x1, y1);
    if h1 == 1
        if x_mean(i) > y_mean(i)
            ans = [ans,1];
        elseif x_mean(i) == y_mean(i)
            ans = [ans,0];
        else
            ans = [ans,-1];
        end
    else
        ans = [ans,0];
    end
end
disp(ans);
    

