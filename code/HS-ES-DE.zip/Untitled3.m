clear all;
rand('state',sum(100*clock));
%rand('state',1);
%Dimension=[10 30 50 100];
Dimension=[30];
Xmin=-100;
Xmax=100;
runs=30;
%fhd=str2func('cec14_func');
fhd=@cec14_func;
beishu = 1;
%%% change freq


for dimension=1
    D=Dimension(dimension);
    Max_FEs=10000*D*beishu;
    problem_size = D;
    freq_inti = 0.5;
    val_2_reach = 10^(-8);
    max_region = 100.0;
    min_region = -100.0;
    lu = [-100 * ones(1, problem_size); 100 * ones(1, problem_size)];
    pb = 0.4;
    ps_EPS = .5;
    S.Ndim = problem_size;
    S.Lband = ones(1, S.Ndim)*(-100);
    S.Uband = ones(1, S.Ndim)*(100);

    GenMaxSelected = 250; %%% For local search

    %%%% Count the number of maximum generations before as NP is dynamically
    %%%% decreased 
    G_Max=choose_Gmax(problem_size);
    run_funcvals = [];
    RecordFEsFactor = ...
    [0.01, 0.02, 0.03, 0.05, 0.1, 0.2, 0.3, 0.4, ...
    0.5, 0.6, 0.7, 0.8, 0.9, 1.0];
    progress = numel(RecordFEsFactor);
   
    fp = fopen("ans_30_last.txt",'a+');
    for func=[1:30]
        %func = 16;
        outcome = [];
        optimum = func * 100.0;
        S.FuncNo = func;
        result_pos_my = zeros(1,D);
        result_pos_he = zeros(1,D);
        lambda = 80+floor(3*log(D));
        for jj=1:runs
            temp_best=[]; %用于记录一轮中每一次CMA的最优值
            FEs=0;
            total=80;
            vara=[func,-100,100,zeros(1,100),0,0];
            meanval = rand(1,D);
            turns = 0;
            nn = 2;%指定CMA运行代数
            for times=[1:nn]
                turns = turns + 1;
                [arx,arfitness,FEs]=CMA(meanval,Max_FEs,D,fhd,vara,FEs,total);
                bestans = min(arfitness)-optimum;
                temp_best = [temp_best,bestans];
                disp(['第',num2str(turns),'次: ','FES:',num2str(FEs),' min:',num2str(bestans)]);
                meanval=chafen(total,arx,D);
            end
            
            
      
      xxx = 0;
      run_funcvals = [];  
    %%  parameter settings for L-SHADE
    p_best_rate = 0.11;    %0.11
    arc_rate = 1.4;
    memory_size = 5;
    %pop_size = 18 * problem_size;   %18*D
    pop_size = 50;
    SEL = round(ps_EPS*pop_size);

    max_pop_size = 90.0;
    min_pop_size = 4.0;

     %nfes = 0;
     %Max_FEs = Max_FEs - FEs;
     nfes = FEs;
    
    %% Initialize the main population
    %popold = repmat(lu(1, :), pop_size, 1) + rand(pop_size, problem_size) .* (repmat(lu(2, :) - lu(1, :), pop_size, 1));
    
    popold = repmat(lu(1, :), pop_size, 1) + rand(pop_size, problem_size) .* (repmat(lu(2, :) - lu(1, :), pop_size, 1));
    pop = chafen1(floor(3*log(D))+80,arx,D,pop_size);
    
    vara=[func,-100,100,zeros(1,100),0,0];
    %fitness = feval(fhd,pop',func);
    fitness = feval(fhd,pop',vara(:));
    fitness = fitness';
    

    everbestfitall = realmax();
    everbestfitinrun = realmax();
    curbestfit = fitness(1);
    prebestfit = realmax();
        
    bsf_fit_var = 1e+30;
    bsf_index = 0;
    bsf_solution = zeros(1, problem_size);
    
    %%%%%%%%%%%%%%%%%%%%%%%% for out
    for i = 1 : pop_size
        nfes = nfes + 1;
        
        if fitness(i) < bsf_fit_var
            bsf_fit_var = fitness(i);
            bsf_solution = pop(i, :);
            bsf_index = i;
        end
        
        if nfes > Max_FEs; break; end
    end
    %%%%%%%%%%%%%%%%%%%%%%%% for out
    everbestfitall = min(fitness)-optimum;
    
    %fprintf(fp,'%d %e %e %e\r\n', nfes,  mean(fitness)-optimum, min(fitness)-optimum, everbestfitall);    %输出格式
    %disp(['nfes:' ,num2str(nfes),'  mean:',num2str(mean(fitness)-optimum), '  min:',num2str(min(fitness)-optimum),'  everbestfitall:' num2str(everbestfitall)] );
    %%%%%%%%%%%%%%%%%%%%%%%% for out
    
    %%% Initialize LS population
    %locacl search based on gaussian walk
    flag_LS = false;
    counter = 0;
    popsize_LS = 10;
    
    %%% Initialize LS population for re-start 
    %10*30
    popLS = repmat(lu(1, :), popsize_LS, 1) + rand(popsize_LS, problem_size) .* (repmat(lu(2, :) - lu(1, :), popsize_LS, 1));
    fitness_LS = feval(fhd,popLS',func);
    
    fitness_LS = fitness_LS';
    nfes = nfes + popsize_LS;
    %%%%%%%%%%%%%
    [Sorted_FitVector, Indecis] = sort(fitness_LS);
    popLS = popLS(Indecis,:);%sorting the points based on obtaind result
    %==========================================================================
     %Finding the Best point in the group=======================================
    BestPoint = popLS(1, :);
    F = Sorted_FitVector(1);%saving the first best fitness
    %%%%%%%%%%%%%
    
    
 
    run_funcvals = [run_funcvals;fitness];
    run_funcvals = [run_funcvals;fitness_LS]; 
    
    memory_sf = 0.5 .* ones(memory_size, 1);
    memory_cr = 0.5 .* ones(memory_size, 1);

    memory_freq = freq_inti*ones(memory_size, 1);
    memory_pos = 1;

    archive.NP = arc_rate * pop_size; % the maximum size of the archive
    archive.pop = zeros(0, problem_size); % the solutions stored in te archive
    archive.funvalues = zeros(0, 1); % the function value of the archived solutions

    %% main loop
    gg=0;  %%% generation counter used For Sin
    igen =1;  %%% generation counter used For LS
 
    while nfes < Max_FEs
      gg=gg+1;
      if gg == 1
        gg = 1;
      else
        pop = popold;
      end
      pop = popold; % the old population becomes the current population
      [temp_fit, sorted_index] = sort(fitness, 'ascend');

      mem_rand_index = ceil(memory_size * rand(pop_size, 1));
      mu_sf = memory_sf(mem_rand_index);
      mu_cr = memory_cr(mem_rand_index);
      mu_freq = memory_freq(mem_rand_index);

      %% for generating crossover rate
      cr = normrnd(mu_cr, 0.1);
      term_pos = find(mu_cr == -1);
      cr(term_pos) = 0;
      cr = min(cr, 1);
      cr = max(cr, 0);
      
      %% for generating scaling factor
      sf = mu_sf + 0.1 * tan(pi * (rand(pop_size, 1) - 0.5));
      pos = find(sf <= 0);
      
      while ~ isempty(pos)
          sf(pos) = mu_sf(pos) + 0.1 * tan(pi * (rand(length(pos), 1) - 0.5));
          pos = find(sf <= 0);
      end
      
      
      freq = mu_freq + 0.1 * tan(pi*(rand(pop_size, 1) - 0.5));
      pos_f = find(freq <=0);
      while ~ isempty(pos_f)
        freq(pos_f) = mu_freq(pos_f) + 0.1 * tan(pi * (rand(length(pos_f), 1) - 0.5));
        pos_f = find(freq <= 0);
      end

      sf = min(sf, 1);
      freq = min(freq, 1);
      
      if(nfes <= Max_FEs/2)
          c=rand;
          if(c<0.5)
              sf = 0.5.*( sin(2.*pi.*freq_inti.*gg+pi) .* ((G_Max-gg)/G_Max) + 1 ) .* ones(pop_size,problem_size);
          else
              sf = 0.5 *( sin(2*pi .* freq(:, ones(1, problem_size)) .* gg) .* (gg/G_Max) + 1 ) .* ones(pop_size,problem_size);
          end
      end
      
      r0 = [1 : pop_size];
      popAll = [pop; archive.pop];
      [r1, r2] = gnR1R2(pop_size, size(popAll, 1), r0);
      
      pNP = max(round(p_best_rate * pop_size), 2); %% choose at least two best solutions
      randindex = ceil(rand(1, pop_size) .* pNP); %% select from [1, 2, 3, ..., pNP]
      randindex = max(1, randindex); %% to avoid the problem that rand = 0 and thus ceil(rand) = 0
      pbest = pop(sorted_index(randindex), :); %% randomly choose one of the top 100p% solutions

      prebestfit = curbestfit;     
      [curbestfit,ind] = min(fitness);
      curbestchrom = popold(ind, :);
      if prebestfit < everbestfitinrun
          everbestfitinrun = prebestfit;
      end      
      if prebestfit < everbestfitall
          everbestfitall = prebestfit;
      end
     
      
      vi = pop + sf(:, ones(1, problem_size)) .* (pbest - pop + pop(r1, :) - popAll(r2, :));
      vi = boundConstraint(vi, pop, lu);
      
      mask = rand(pop_size, problem_size) > cr(:, ones(1, problem_size)); % mask is used to indicate which elements of ui comes from the parent
      rows = (1 : pop_size)'; cols = floor(rand(pop_size, 1) * problem_size)+1; % choose one position where the element of ui doesn't come from the parent
      jrand = sub2ind([pop_size problem_size], rows, cols); mask(jrand) = false;
      ui = vi; ui(mask) = pop(mask);

      children_fitness = feval(fhd, ui', func);
      children_fitness = children_fitness';

     
      %%%% To check stagnation
      flag = false;
      bsf_fit_var_old = bsf_fit_var;
      %%%%%%%%%%%%%%%%%%%%%%%% for out
      for i = 1 : pop_size
          nfes = nfes + 1; 
          if children_fitness(i) < bsf_fit_var
              bsf_fit_var = children_fitness(i);
              bsf_solution = ui(i, :);
              bsf_index = i; 
          end
          
          if nfes > Max_FEs; break; end
      end      
      %%%%%%%%%%%%%%%%%%%%%%%% for out

      dif = abs(fitness - children_fitness);


      %% I == 1: the parent is better; I == 2: the offspring is better
      I = (fitness > children_fitness);
      goodCR = cr(I == 1);  
      goodF = sf(I == 1);
      goodFreq = freq(I == 1);
      dif_val = dif(I == 1);

%      isempty(popold(I == 1, :))   
      archive = updateArchive(archive, popold(I == 1, :), fitness(I == 1));

      [fitness, I] = min([fitness, children_fitness], [], 2);
      
      run_funcvals = [run_funcvals; fitness];
      
      popold = pop;
      popold(I == 2, :) = ui(I == 2, :);

      num_success_params = numel(goodCR);

      if num_success_params > 0
          sum_dif = sum(dif_val);
          dif_val = dif_val / sum_dif;
          
          %% for updating the memory of scaling factor
          memory_sf(memory_pos) = (dif_val' * (goodF .^ 2)) / (dif_val' * goodF);
          
          %% for updating the memory of crossover rate
          if max(goodCR) == 0 || memory_cr(memory_pos)  == -1
              memory_cr(memory_pos)  = -1;
          else
              memory_cr(memory_pos) = (dif_val' * (goodCR .^ 2)) / (dif_val' * goodCR);
          end
          
          %% for updating the memory of freq
          if max(goodFreq) == 0 || memory_freq(memory_pos)  == -1
              memory_freq(memory_pos)  = -1;
          else
              memory_freq(memory_pos) = (dif_val' * (goodFreq .^ 2)) / (dif_val' * goodFreq);
          end
          
          memory_pos = memory_pos + 1;
          if memory_pos > memory_size;  memory_pos = 1; end
      end

      %% for resizing the population size
      plan_pop_size = round((((min_pop_size - max_pop_size) / Max_FEs) * nfes) + max_pop_size);

      if pop_size > plan_pop_size
          reduction_ind_num = pop_size - plan_pop_size;
          if pop_size - reduction_ind_num <  min_pop_size; 
              reduction_ind_num = pop_size - min_pop_size;
          end
          
          pop_size = pop_size - reduction_ind_num;
          SEL = round(ps_EPS*pop_size);
          for r = 1 : reduction_ind_num
              [valBest indBest] = sort(fitness, 'ascend');
              worst_ind = indBest(end);
              popold(worst_ind,:) = [];
              pop(worst_ind,:) = [];
              fitness(worst_ind,:) = [];
          end
          
          archive.NP = round(arc_rate * pop_size);
          
          if size(archive.pop, 1) > archive.NP
              rndpos = randperm(size(archive.pop, 1));
              rndpos = rndpos(1 : archive.NP);
              archive.pop = archive.pop(rndpos, :);
          end
      end
       %%%%%%%%%%%%%%% Call LS based on Gaussian works when NP is less than 20 for the first time  %%%%%
      if pop_size <= 20
          counter = counter + 1;
      end

      if counter == 1
          flag_LS = true;
      else
          flag_LS = false;
      end

      if flag_LS == true
          r_index = randi([1 pop_size],1,popsize_LS); %1*10的1-20随机数
          %%% Pick 10 random individuals from L-SHADE pop
          for gen_LS = 0 : GenMaxSelected
              New_Point = [];%creating new point
              FitVector = [];%creating vector of fitness functions

              for i = 1 : popsize_LS
                  [NP, fit] = LS_Process(popLS(i,:),S,gg,BestPoint);
                  New_Point = [New_Point;NP];
                  FitVector = [FitVector,fit];
              end
           
              %%%%
              fittemp = FitVector;
              for i = 1 : popsize_LS
                  %%% Update those 10 random individuals from pop L-SHADE
                  if FitVector(i) < fitness(r_index(i))    %比较新产生的个体和原来群体的适应值 若新产生的好，就替换
                      fitness (r_index(i)) = FitVector(i);
                      pop(r_index(i),:) = New_Point(i,:);
                      
                  else
                      fittemp(i) =  fitness (r_index(i));  % fittemp记录所有差解的适应值 fitness记录好的 FitVector记录新的
                  end

                  %%%% Update best individual L-SHADE
                  if FitVector(i) < bsf_fit_var
                      bsf_fit_var = FitVector(i);
                      bsf_solution = New_Point(i,:);
                  end

                  nfes = nfes + 1;
                  if nfes > Max_FEs; break; end
              end
              
              %%%%%% To recored those changes
              fittemp = fittemp';
              run_funcvals = [run_funcvals; fittemp];
              
              %%%%%%%%%%%%%%

              [SortedFit,SortedIndex] = sort(FitVector);
              New_Point = New_Point(SortedIndex,:);
              BestPoint = New_Point(1,:);%first point is the best
              BestFitness = SortedFit(1,1);
              popLS = New_Point;
          end
      end
      if everbestfitall > min(fitness)-optimum
          everbestfitall = min(fitness)-optimum;
      end
      
      if (nfes / Max_FEs) >= (xxx / 5)
          if  xxx > 0
              
              %fprintf(fp,'%d %e %e %e\r\n', nfes, mean(fitness)-optimum, min(fitness)-optimum, everbestfitall);
              %disp(['FEs:' ,num2str(nfes),'  mean:',num2str(mean(fitness)-optimum), '  min:',num2str(min(fitness)-optimum),'  everbestfitall:' num2str(everbestfitall)] );
              disp(['FEs:' ,num2str(nfes),'  min:',num2str(min(fitness)-optimum)]); 

          end
          xxx = xxx + 1;
      end
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      
      
    end %%%%%%%%nfes
    
    bsf_error_val = bsf_fit_var - optimum;
    outcome = [outcome bsf_error_val];
      
      temp_best = [temp_best,min(fitness)-optimum];
      result_pos_my(jj) = min(temp_best);
      disp(['第',num2str(jj),'轮，全局最优解: ',' min:',num2str(min(temp_best))]);
        end
        ans_mean_my = mean(result_pos_my);
        ans_std_my = std(result_pos_my);
        fprintf(fp,'%e %e ', ans_mean_my,ans_std_my);
        for x = 1:runs
            fprintf(fp,'%e ', result_pos_my(x));
        end
        fprintf(fp,'\n');
        

       
    end
end



function curdiv=f(pos,D,total)
    curdiv = 0.0;
    n=D;
    mixPop=pos;
    k = total;
    curdiv = 0.0;
    Xmin=-100;
    Xmax=100;
    for x =1 : n
        midpoint(x) = median(mixPop(:,x));
    end
    distobest = 1 :k;
    for x = 1: k
        distobest (x)= 0;
        for y = 1 : n
            distobest(x) = distobest(x) + abs((mixPop(x,y) - midpoint(y))/(Xmax -Xmin));
        end
        distobest (x) = distobest (x) / n;
        curdiv = curdiv + distobest (x);
    end
    curdiv = curdiv /k;
end


function [arx,arfitness,FEs]=CMA(meanval,stopeval,N,fhd,vara,FEs,total)
    Max_FEs=10000*N*1;
    xmean = meanval';    % 初始化均值 objective variables initial point
    sigma = 0.2;          % 初始化标准差 coordinate wise standard deviation (step size)
    stopfitness = 1e-13;  % 停止优化指标stop if fitness < stopfitness (minimization)
    %stopeval = Max_FEs - FEs;   % 迭代次数最大值stop after stopeval number of function evaluations
    
    lambda = 80+floor(3*log(N));  %后代数量 population size, offspring number
    mu = lambda/2;               % number of parents/points for recombination
    weights = log(mu+1/2)-log(1:mu)'; % muXone array for weighted recombination
    mu = floor(mu);
    weights = weights/sum(weights);     % normalize recombination weights array
    mueff=sum(weights)^2/sum(weights.^2); %后代方差有效数量 variance-effectiveness of sum w_i x_i

    % Strategy parameter setting: Adaptation
    cc = (4 + mueff/N) / (N+4 + 2*mueff/N); % time constant for cumulation for C
    cs = (mueff+2) / (N+mueff+5);  % t-const for cumulation for sigma control
    c1 = 2 / ((N+1.3)^2+mueff);    %rank-one的学习率 learning rate for rank-one update of C
    cmu = min(1-c1, 2 * (mueff-2+1/mueff) / ((N+2)^2+mueff));  % rank-mu的学习率 for rank-mu update
    damps = 1 + 2*max(0, sqrt((mueff-1)/(N+1))-1) + cs; % damping for sigma
    % usually close to 1
    % Initialize dynamic (internal) strategy parameters and constants
    pc = zeros(N,1); ps = zeros(N,1);   % evolution paths for C and sigma
    B = eye(N,N);                       % B defines the coordinate system
    DD = ones(N,1);                      % diagonal D defines the scaling
    C = B * diag(DD.^2) * B';            % covariance matrix C
    invsqrtC = B * diag(DD.^-1) * B';    % C^-1/2
    eigeneval = 0;                      % track update of B and D
    chiN=N^0.5*(1-1/(4*N)+1/(21*N^2));  % expectation of
    %   ||N(0,I)|| == norm(randn(N,1))


    % -------------------- Generation Loop --------------------------------
    counteval = 0;  % the next 40 lines contain the 20 lines of interesting code
    beforebest = 9999999;
    gn = 0;
    Gn = 50;
    flag = 1;
    T = 1e-14;
    while counteval < stopeval
    % Generate and evaluate lambda offspring（随机产生后代）
        if flag == 0
            beforebest = arfitness(1);
        end
        
        for k=1:lambda
            arx(:,k) = xmean + sigma * B * (DD .* randn(N,1)); % m + sig * Normal(0,C)
            arfitness(k)=feval(fhd,arx(:,k),vara(:)); % objective function call
            counteval = counteval+1;
            FEs = FEs + 1;
        end
        % Sort by fitness and compute weighted mean into xmean（排序，选择值较小的采样点）
        [arfitness, arindex] = sort(arfitness);  % minimization
        if flag == 1
            flag = 0;
        end
        xold = xmean;
        xmean = arx(:,arindex(1:mu)) * weights;  % recombination, new mean value（新的均值）

        % Cumulation: Update evolution paths（更新进化路径，在协方差矩阵更新的时候利用，协方差更新的方法：rank one 和rank U 融合的方式）
        ps = (1-cs) * ps ...
        + sqrt(cs*(2-cs)*mueff) * invsqrtC * (xmean-xold) / sigma;
        hsig = sum(ps.^2)/(1-(1-cs)^(2*counteval/lambda))/N < 2 + 4/(N+1);
        pc = (1-cc) * pc ...
        + hsig * sqrt(cc*(2-cc)*mueff) * (xmean-xold) / sigma;

        % Adapt covariance matrix C（更新协方差矩阵）
        artmp = (1/sigma) * (arx(:,arindex(1:mu)) - repmat(xold,1,mu));  % mu difference vectors
        C = (1-c1-cmu) * C ...                   % regard old matrix
        + c1 * (pc * pc' ...                % plus rank one update
        + (1-hsig) * cc*(2-cc) * C) ... % minor correction if hsig==0
        + cmu * artmp * diag(weights) * artmp'; % plus rank mu update

        % Adapt step size sigma更新步长
        sigma = sigma * exp((cs/damps)*(norm(ps)/chiN - 1));

        % Update B and D from C
        if counteval - eigeneval > lambda/(c1+cmu)/N/10  % to achieve O(N^2)
            eigeneval = counteval;
            C = triu(C) + triu(C,1)'; % enforce symmetry
            [B,DD] = eig(C);           % eigen decomposition, B==normalized eigenvectors
            DD = sqrt(diag(DD));        % D contains standard deviations now
            invsqrtC = B * diag(DD.^-1) * B';
        end

        % Break, if fitness is good enough or condition exceeds 1e14, better termination methods are advisable
        if arfitness(1) <= stopfitness || max(DD) > 1e7 * min(DD)
            break;
        end
        
        %停止进步则计数，计数达到一定程度就跳出
        if (abs(beforebest - arfitness(1)) / beforebest) <= T  
            gn = gn + 1;
        else
            gn = 0;
        end
        
        
        if gn >= Gn
            gn = 0;
            break;
        end
        
        if FEs + lambda > Max_FEs
            break;
        end
    end
    
    for k=1:total
        arx(:,k) = xmean + sigma * B * (DD .* randn(N,1));
    end
    
    
end

function meanval=chafen(total,arx,D)
    pos = transpose(arx);
    rate = 0.5;
    zero_pos = zeros(total,D);
    xy_times = 50; %差分演化的代数
    for index_times = [1:xy_times]
        for index_i=[1:total]
            r1 = randi(total,1,1);
            r2 = randi(total,1,1);
            r3 = randi(total,1,1);
            while r1 == r2 | r1 == r3 | r2 == r3
                r1 = randi(total,1,1);
                r2 = randi(total,1,1);
                r3 = randi(total,1,1);
            end
            x1 = pos(r1,:);
            x2 = pos(r2,:);
            x3 = pos(r3,:);
            v1 = x3 + rate*(x1-x2);
            %seq = randperm(30);
            %seq = seq(1:15);
            only = randi(D,1,1);
            for index_ii = [1:D]
                if index_ii == only
                    continue
                end
                prorate = rand(1); %概率
                if prorate < 0.5
                    v1(index_ii) = x3(index_ii);
                end
            end
            zero_pos (index_i,:) = v1;
        end
        pos = zero_pos;
    end
    seq1 = randperm(total);
    rate_map = 0.8;
    map_pos = rate_map*total;
    seq = seq1(1:map_pos);
    for index1=[1:map_pos]
        pos(seq(index1),:) = -1*pos(seq(index1),:);
    end
    meanval=mean(pos(1:total,:));
end

function G_Max=choose_Gmax(problem_size)
    G_Max = 0;
    if problem_size == 10
        G_Max = 2163;
    end
    if problem_size == 30
        G_Max = 2745;
    end
    if problem_size == 50
        G_Max = 3022;
    end
    if problem_size == 100
        G_Max = 3401;
    end
end


function pos_new=chafen1(total,arx,D,pop_size)
    pos = transpose(arx);
    rate = 0.5;
    zero_pos = zeros(total,D);
    xy_times = 30; %差分演化的代数
    for index_times = [1:xy_times]
        for index_i=[1:total]
            r1 = randi(total,1,1);
            r2 = randi(total,1,1);
            r3 = randi(total,1,1);
            while r1 == r2 | r1 == r3 | r2 == r3
                r1 = randi(total,1,1);
                r2 = randi(total,1,1);
                r3 = randi(total,1,1);
            end
            x1 = pos(r1,:);
            x2 = pos(r2,:);
            x3 = pos(r3,:);
            v1 = x3 + rate*(x1-x2);
            %seq = randperm(30);
            %seq = seq(1:15);
            only = randi(D,1,1);
            for index_ii = [1:D]
                if index_ii == only
                    continue
                end
                prorate = rand(1); %概率
                if prorate < 0.5
                    v1(index_ii) = x3(index_ii);
                end
            end
            zero_pos (index_i,:) = v1;
        end
        pos = zero_pos;
    end
    seq1 = randperm(total);
    rate_map = 0.3;
    map_pos = rate_map*total;
    seq = seq1(1:map_pos);
    for index1=[1:map_pos]
        pos(seq(index1),:) = -1*pos(seq(index1),:);
    end
    randIndex = randperm(size(pos,1));
    randIndex = randIndex(1:pop_size);
    pos_new = pos(randIndex,:);

end
